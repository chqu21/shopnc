<?php
defined('InShopNC') or exit('Access Invalid!');


if(file_exists('../data/config/config.ini.php')){require('../data/config/config.ini.php');}else{exit('config error');}


define('DB_HOST',$config['db'][1]['dbhost'].':'.$config['db'][1]['dbport']);
define('DB_NAME',$config['db'][1]['dbname']);
define('DB_USER',$config['db'][1]['dbuser']);
define('DB_PWD',$config['db'][1]['dbpwd']);

define('DB_PRE',$config['tablepre']);
define('CHARSET',$config['db'][1]['dbcharset']);	//UTF-8,GBK

define('SiteUrl',"http://o2o.shopncdemo.com");
define('DS','/');

@date_default_timezone_set('Asia/Shanghai');


?>