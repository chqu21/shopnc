<?php
	require("alipay.config.php");
	require("lib/alipay_submit.class.php");
	
	class Alipay{
		private $format = 'xml';//返回格式
		private $v		= '2.0';//返回格式
		private $order	= array(); //订单编号

		public function __construct($order){
			$this->order   = $order;
		}

		public function submit(){
			global $alipay_config;

			$format = $this->format;
			$v		= $this->v;
			$req_id	= date("Ymdhis");
			$notify_url = SiteUrl.'/mobile/alipay/notify_url.php';
			$call_back_url = SiteUrl.'/mobile/alipay/call_back_url.php';

			$seller_email  = $this->order['email'];//卖家支付宝帐户
			$out_trade_no  = $this->order['order_sn'];//商户订单号
			$subject	   = $this->order['item_name'];//订单名称

			$total_fee	   = $this->order['price'];

			//请求业务参数详细
			$req_data = '<direct_trade_create_req><notify_url>' . $notify_url . '</notify_url><call_back_url>' . $call_back_url . '</call_back_url><seller_account_name>' . $seller_email . '</seller_account_name><out_trade_no>' . $out_trade_no . '</out_trade_no><subject>' . $subject . '</subject><total_fee>' . $total_fee . '</total_fee></direct_trade_create_req>';
			
			//构造要请求的参数数组，无需改动
			$para_token = array(
					"service" => "alipay.wap.trade.create.direct",
					"partner" => trim($alipay_config['partner']),
					"sec_id" => trim($alipay_config['sign_type']),
					"format"	=> $format,
					"v"	=> $v,
					"req_id"	=> $req_id,
					"req_data"	=> $req_data,
					"_input_charset"	=> trim(strtolower($alipay_config['input_charset']))
			);

			//建立请求
			$alipaySubmit = new AlipaySubmit($alipay_config);
			$html_text = $alipaySubmit->buildRequestHttp($para_token);

			//URLDECODE返回的信息
			$html_text = urldecode($html_text);

			//解析远程模拟提交后返回的信息
			$para_html_text = $alipaySubmit->parseResponse($html_text);

			//获取request_token
			$request_token = $para_html_text['request_token'];


			/**************************根据授权码token调用交易接口alipay.wap.auth.authAndExecute**************************/

			//业务详细
			$req_data = '<auth_and_execute_req><request_token>' . $request_token . '</request_token></auth_and_execute_req>';
			//必填

			//构造要请求的参数数组，无需改动
			$parameter = array(
					"service" => "alipay.wap.auth.authAndExecute",
					"partner" => trim($alipay_config['partner']),
					"sec_id" => trim($alipay_config['sign_type']),
					"format"	=> $format,
					"v"	=> $v,
					"req_id"	=> $req_id,
					"req_data"	=> $req_data,
					"_input_charset"	=> trim(strtolower($alipay_config['input_charset']))
			);

			//建立请求
			$alipaySubmit = new AlipaySubmit($alipay_config);
			$html_text = $alipaySubmit->buildRequestForm($parameter, 'get', '确认');
			echo $html_text;
			exit;
		}
	}
?>