<?php
error_reporting(7);
define('InShopNC',1);

define('BasePath',dirname(__FILE__));


if(file_exists('config.php')){require('config.php');}else{exit();}

define('DBHOST',$config['db'][1]['dbhost']);
define('DBUSER',$config['db'][1]['dbuser']);
define('DBPWD',$config['db'][1]['dbpwd']);
define('DBNAME',$config['db'][1]['dbname']);
define('DBPORT',$config['db'][1]['dbport']);
define('CHARSET',$config['db'][1]['dbcharset']);
define('DBPRE',$config['tablepre']);
define('MD5_KEY',$config['md5_key']);

if(file_exists('../global.php')){require('../global.php');}else{exit();}
if(file_exists('../data/cache/setting.php')){ $setting = require('../data/cache/setting.php');}else{exit();}
if(file_exists('model.class.php')){require('model.class.php');}else{exit();}

//总是输出UTF-8编码
header("Content-type: text/html; charset=utf-8");

class run{
	/**
	 * 内部服务器错误（数据库错误、PHP处理异常等所有异常情况）
	 * 
	 */
	const ERROR_500 = '500';
	/**
	 * 参数不正确
	 *
	 */
	const ERROR_404 = '404';
	/**
	 * 正确返回
	 *
	 */
	const SUCC	= '200';
	/**
	 * 默认页码
	 *
	 */
	const  PAGE_NUM = 1;
	/**
	 * 默认页码
	 *
	 */
	const PAGE_SIZE = 10;
	/**
	 * 存放GET过来的信息
	 *
	 * @var array
	 */
	private $_get;
	private $order_sn;
	public function __construct(){
		$this->_validate();
		$this->index();
	}

	private function _validate(){

		if (!empty($_GET)){
			$this->_get = $_GET;
		}else{
			$this->_get = $_POST;
		}
		
		if (empty($this->_get)){
			exit($this->callback('',self::ERROR_404));
		}

//		在数据库底层完成转码
		//fliter($this->_get);
	}

	private function index(){
		$func = '_'.$this->_get['commend'];
		if (method_exists($this,$func)){
			$this->$func();
		}else{
			exit($this->callback('',self::ERROR_404));	
		}
	}
	

	/*
	 *	城市列表	
	 */	
	private function _city(){
		$model			= M();
		$condition		=	array();
		$condition['parent_area_id'] = '0';// 0代表城市 1代表区域 2代表商区
		$data = $model->fields("area_id,area_name,first_letter,hot_city")->table('area')->where($condition)->order('first_letter asc')->select();	
		echo json_encode(array('code'=>self::SUCC,'datas'=>$data));
		exit;
	}

	/*
	 *	分类列表	
	 */	
	private function _category(){
		$model = M();
		$parent_class = $model->fields('class_id,class_name')->table('store_class')->where(array('parent_class_id'=>'0'))->order('class_sort asc')->select();//一级分类
		
		$class_id	=	isset($_GET['class_id'])?intval($_GET['class_id']):2;//class_id = 2(餐饮美食)
		$class = $model->fields('class_id,class_name')->table('store_class')->where(array('parent_class_id'=>$class_id))->select();//二级分类

		echo json_encode(array('code'=>self::SUCC,'datas'=>array('parent_class'=>$parent_class,'class'=>$class)));
		exit;
	}


	/*
	 *	分类店铺
	 */		
	private function _storeclass(){
		$offset = isset($_GET['pagenumber'])?intval($_GET['pagenumber']):self::PAGE_NUM;
		$number = isset($_GET['pagesize'])?intval($_GET['pagesize']):self::PAGE_SIZE;
		$offset = ($offset - 1)*$number;
		
		$model = M();
		$store = $model->fields('store_id,store_name,pic,address,person_consume')->table('store')->where(array('s_class_id'=>intval($_GET['class_id']),'city_id'=>intval($_GET['city_id'])))->limit("{$offset},{$number}")->select();
		$count = 	$model->table('store')->where(array('s_class_id'=>intval($_GET['class_id']),'city_id'=>intval($_GET['city_id'])))->count();
		$total = $count - $offset;

		if(!empty($store)){
			foreach($store as $key=>$val){
				$store[$key]['pic'] = SiteUrl.'/data/upload/shop/store/'.$val['pic'];
			}
		}
	
		$data	=	array(
			'code'		=>	self::SUCC,
			'datas'		=>	$store,
			'count'		=>	$count,
			'haveMore'	=>	$total>=$number?'true':'false'
		);
		echo json_encode($data);
		exit;
	}


	/*
	 *	团购列表
	 */	
	private function _groupbuy(){
		$offset = isset($_GET['pagenumber'])?intval($_GET['pagenumber']):self::PAGE_NUM;
		$number = isset($_GET['pagesize'])?intval($_GET['pagesize']):self::PAGE_SIZE;
		$offset = ($offset - 1)*$number;
		
		$default_city = unserialize($GLOBALS['setting']['default_city']);
		$city_id = isset($_GET['city_id'])?$_GET['city_id']:$default_city['area_id'];
		$model = M();
		$data = $model->fields("group_id,group_name,original_price,group_price,buyer_count,group_pic")->table('groupbuy')->where(array('city_id'=>$city_id,'gt'=>array('end_time'=>time()),'elt'=>array('start_time'=>time())))->limit("{$offset},{$number}")->select();

		$pic_url = SiteUrl.'/data/upload/shop/groupbuy/';
		
		if(!empty($data)){
			foreach($data as $k=>$v){
				$data[$k]['group_pic'] = $pic_url.$v['group_pic'];
			}	
		}
		$count = $model->table('groupbuy')->where(array('city_id'=>$city_id,'is_audit'=>2))->count();//审核通过的团购
		$total = $count-$offset*$number;
		
		$data = array(
				'code'		=>	self::SUCC,//正常返回相应
				'datas'		=>	$data,
				'count'		=>	$count,
				'haveMore'	=>	$total>$number?'true':'false'
		);
		echo json_encode($data);
		exit;
	}


	/*
	 *	团购详细
	 */	
	private function _groupbuydetail(){		
		$model = M();
		$group = $model->fields('group_id,group_name,group_help,store_id,store_name,original_price,group_price,buyer_count,buyer_limit,buyer_num,group_intro,group_pic')->table('groupbuy')->where(array('group_id'=>intval($_GET['group_id'])))->find();
		
		if(empty($group)){
			throw_exception();
		}

		$group['group_pic']		= SiteUrl.'/data/upload/shop/groupbuy/'.$group['group_pic'];
		$group['group_help']	= htmlspecialchars_decode($group['group_help']);
		$group['group_intro']	= htmlspecialchars_decode($group['group_intro']);
		
		echo json_encode(array('code'=>self::SUCC,'datas'=>$group));
		exit;
	}
	
	private function _member_groupbuy(){
		//身份验证
		$this->auth();

		$offset = isset($_GET['pagenumber'])?intval($_GET['pagenumber']):self::PAGE_NUM;
		$number = isset($_GET['pagesize'])?intval($_GET['pagesize']):self::PAGE_SIZE;
		$offset = ($offset - 1)*$number;
		
		
		$condition	=	array(
			'member_id'	=>	intval($_GET['member_id']),
			'state'		=>	intval($_GET['state'])
		);
		
		$model = M();
		$group = $model->fields('order_sn,item_name,price,state,group_pic')->table('order')->join("left join ".DBPRE."groupbuy on ".DBPRE."order.item_id = ".DBPRE."groupbuy.group_id")->where($condition)->limit("{$offset},{$number}")->select();
		
		$count = $model->table('order')->join("left join ".DBPRE."groupbuy on ".DBPRE."order.item_id = ".DBPRE."groupbuy.group_id")->where($condition)->count();
		
		$pic_url = SiteUrl.'/data/upload/shop/groupbuy/';
		if(!empty($group)){
			foreach($group as $k=>$v){
				$group[$k]['group_pic'] = $pic_url.$v['group_pic'];
			}
		}
		
		$total = $count-$offset*$number;
		
		$data = array(
				'code'		=>	self::SUCC,
				'datas'		=>	$group,
				'count'		=>	$count,
				'haveMore'	=>	$total>$number?'true':'false'
		);
		echo json_encode($data);
		exit;
	}
	
	private function _member_coupon(){
		//身份验证
		$this->auth();
		
		$offset = isset($_GET['pagenumber'])?intval($_GET['pagenumber']):self::PAGE_NUM;
		$number = isset($_GET['pagesize'])?intval($_GET['pagesize']):self::PAGE_SIZE;
		$offset = ($offset - 1)*$number;
			
		
		$condition	=	array(
			'member_id'	=>	intval($_GET['member_id'])	
		);
		$model = M();
		$data = $model->fields('coupon_name,download_time,download_type')->table('coupon_download')->where($condition)->limit("{$offset},{$number}")->select();
		
		$count = $model->table('coupon_download')->where($condition)->count();
		$total = $count-$offset*$number;
		
		$data = array(
				'code'		=>	self::SUCC,
				'datas'		=>	$data,
				'count'		=>	$count,
				'haveMore'	=>	$total>$number?'true':'false'
		);
		echo json_encode($data);
		exit;
	}

	
	private function _order(){
		//身份验证
		$this->auth();

		$model = M();
		$group = $model->table('groupbuy')->where(array('is_open'=>1,'group_id'=>intval($_POST['group_id']),'is_audit'=>2))->find();//is_open=1(1.开启 2.关闭) is_audit=2(1.待审核 2.审核通过 3.审核未通过)
		

		if(empty($group)){
			throw_exception();
		}

		//验证团购是否开始
		if($group['start_time']>time()){
			throw_exception();
		}

		//验证团购是否结束
		if($group['end_time']<time()){
			throw_exception();
		}

		//验证团购数量
		if(intval($_POST['quantity'])>$group['buyer_limit']){
			throw_exception();
		}
		
		$store = $model->table('store')->where(array('store_id'=>$group['store_id']))->find();
		$member= $model->table('member')->where(array('member_id'=>intval($_POST['member_id'])))->find();
	
		$data = array(
			'order_sn'		=>	$this->snOrder(),
			'member_id'		=>	$member['member_id'],
			'member_name'	=>	$member['member_name'],
			'mobile'		=>	$member['mobile'],
			'store_id'		=>	$store['store_id'],
			'store_name'	=>	$store['store_name'],
			'add_time'		=>	time(),
			'order_type'	=>	1,
			'item_id'		=>	$group['group_id'],
			'item_name'		=>	$group['group_name'],
			'number'		=>	intval($_POST['quantity']),
			'price'			=>	intval($_POST['quantity'])*$group['group_price'],
			'state'			=>	1,
			'order_out'		=>	$this->order_sn
		);

		$result = $model->table('order')->insert($data);
		
		if($result){
			$order = $model->table('order')->where(array('order_sn'=>$this->order_sn))->find();
			$order_arr = array(
				'group_name'	=>	$order['item_name'],	//名称
				'number'		=>	$order['number'],	//数量
				'price'			=>	$order['price'],	//总价格
				'order_sn'		=>	$order['order_sn'],	//订单编号
				'predeposit'	=>	$member['predeposit']	//余额
			);
			
			echo json_encode(array('code'=>self::SUCC,'datas'=>$order_arr));
			exit;
		}else{
			throw_exception();	
		}
	}
	
	
	/*
	 * 订单号
	 */
	public function snOrder() {
		$this->order_sn = date('Ymd').substr( implode(NULL,array_map('ord',str_split(substr(uniqid(),7,13),1))) , -8 , 8);
		return $this->order_sn;
	}

	private function _coupon(){
		$offset = isset($_GET['pagenumber'])?intval($_GET['pagenumber']):self::PAGE_NUM;
		$number = isset($_GET['pagesize'])?intval($_GET['pagesize']):self::PAGE_SIZE;
		$offset = ($offset - 1)*$number;
		
		$default_city = unserialize($GLOBALS['setting']['default_city']);
		$city_id = isset($_GET['city_id'])?$_GET['city_id']:$default_city['area_id'];
		
		$model = M();
		$data = $model->fields("coupon_id,coupon_name,coupon_pic,coupon_start_time,coupon_end_time,download_count")->table('coupon')->where(array('city_id'=>$city_id,'gt'=>array('coupon_end_time'=>time()),'elt'=>array('coupon_start_time'=>time()),'audit'=>2))->limit("{$offset},{$number}")->select();//优惠券列表
		
		$count = $model->table('coupon')->where(array('city_id'=>$city_id,'gt'=>array('coupon_end_time'=>time()),'elt'=>array('coupon_start_time'=>time())))->count();

		$total = $count-$offset*$number;
		
		$pic_url = SiteUrl.'/data/upload/shop/coupon/';
		if(!empty($data)){
			foreach($data as $k=>$v){
				$data[$k]['coupon_pic']	= $pic_url.$v['coupon_pic'];
			}
		}
		
		$total = $count-$offset*$number;
		$data = array(
				'code'		=>	self::SUCC,
				'datas'		=>	$data,
				'count'		=>	$count,
				'haveMore'	=>	$total>$number?'true':'false'
		);
		
		echo json_encode($data);
		exit;
	}

	private function _coupondetail(){
		$coupon_id	=	intval($_GET['coupon_id']);
		
		$model  = M();
		$coupon = $model->fields('coupon_name,coupon_pic,coupon_start_time,coupon_end_time,coupon_des,store_name,message,download_count,view_count,short_message')->table('coupon')->where(array('coupon_id'=>$coupon_id,'audit'=>2))->find();//1.待审核 2.审核通过 3.审核未通过
		if(!empty($coupon)){
			$coupon['coupon_pic']	= SiteUrl.'/data/upload/shop/coupon/'.$coupon['coupon_pic'];
			$coupon['coupon_des']	= htmlspecialchars_decode($coupon['coupon_des']);
		}

		echo json_encode(array('code'=>self::SUCC,'datas'=>$coupon));
		exit;
	}
	

	private function _coupondownload(){
		$model  = M();
		$coupon = $model->fields('short_message')->table('coupon')->where(array('coupon_id'=>intval($_GET['coupon_id']),'audit'=>2))->find();
		if(empty($coupon)){
			throw_exception();
		}
		
		
		$post_data	=	array(
				'phone'		=>	trim($_GET['mobile']),
				'text'		=>	$coupon['short_message']
		);

		$ch	=	curl_init();
		curl_setopt($ch,CURLOPT_URL,SiteUrl."/api/message/demo.php");
		curl_setopt($ch,CURLOPT_HEADER, 0);
		curl_setopt($ch,CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch,CURLOPT_POST, 1);
		curl_setopt($ch,CURLOPT_POSTFIELDS, $post_data);
		$output = curl_exec($ch);
		curl_close($ch);
		
		echo json_encode(array('code'=>self::SUCC,'datas'=>true));
		exit;
	}


	private function _card(){
		$offset = isset($_GET['pagenumber'])?intval($_GET['pagenumber']):self::PAGE_NUM;
		$offset = $offset - 1;

		$number = isset($_GET['pagesize'])?intval($_GET['pagesize']):self::PAGE_SIZE;
		$default_city = unserialize($GLOBALS['setting']['default_city']);
		$city_id = isset($_GET['city_id'])?$_GET['city_id']:$default_city['area_id'];
		$model = M();
		$condition	=	array(
			'is_audit'		=>	2,//1.待审核 2.审核通过 3.审核未通过
			'is_card'		=>	1,//0.未开启 1.开启
			'city_id'		=>	$city_id
		);
		
		$cardset	=	array();//会员 会员卡集合
		if(!empty($_GET['member_id'])){
			$membercard = $model->fields('store_id')->table('card_member')->where(array('member_id'=>intval($_GET['member_id'])))->select();			
			if(!empty($membercard)){
				foreach($membercard as $v){
					$cardset[] = $v['store_id'];		
				}
			}
		}
		
		$store  = $model->fields('store_id,store_name,card_discount,address')->table('store')->where($condition)->limit($offset,$number)->select();


		if(!empty($store)){
			foreach($store as $key=>$val){
				$store[$key]['is_store'] = in_array($val['store_id'],$cardset)?1:0;//会员是否已经成为该店会员 1.是 0.否	
			}
		}

		$count = $model->table('store')->where($condition)->count();
		$total = $count-$offset*$number;
		
		$data = array(
				'code'		=>	self::SUCC,
				'datas'		=>	$store,
				'count'		=>	$count,
				'haveMore'	=>	$total>=$number?'true':'false'
		);
		
		echo json_encode($data);
		exit;		
	}
	
	private function _member_card(){
		//身份验证
		$this->auth();
		
		$offset = isset($_GET['pagenumber'])?intval($_GET['pagenumber']):self::PAGE_NUM;
		$number = isset($_GET['pagesize'])?intval($_GET['pagesize']):self::PAGE_SIZE;
		$offset = ($offset - 1)*$number;
	
		$model = M();
		$condition	=	array(
			'is_use'	=>	2,//会员卡 1.未开通 2.开通
			'member_id'	=>	intval($_GET['member_id'])
		);
		$data = $model->fields('card_number,store_name')->table('card_member')->where($condition)->limit("{$offset},{$number}")->select();
			
		$count = $model->table('card_member')->where($condition)->count();
		$total = $count-$offset*$number;
		
		$data = array(
				'code'		=>	self::SUCC,
				'datas'		=>	$data,
				'count'		=>	$count,
				'haveMore'	=>	$total>$number?'true':'false'
		);
		echo json_encode($data);
		exit;
	}

	private function _cardinfo(){
		$store_id = $_GET['store_id'];
		$model = M();
		$data = $model->fields('store_id,store_name,card_discount,address,card_des')->table('store')->where(array('store_id'=>$store_id))->find();
		
		if(!empty($_GET['member_id'])){
			//身份验证
			$this->auth();
			$member = $model->table("card_member")->where(array('member_id'=>intval($_GET['member_id']),'store_id'=>intval($_GET['store_id'])))->find();

			if(!empty($member)){
				if($member['is_use'] == 1){//1.未开通 2.开通
					$data['state']	= 1;
				}elseif($member['is_use'] == 2){
					$data['state']	= 2;
				}
			}else{
				$data['state'] = 3;//未登录
			}
		}else{
			$data['state'] = 3;//未登录
		}

		$data = array(
				'code'		=>	self::SUCC,
				'datas'		=>	$data
		);
		
		echo json_encode($data);
		exit;
	}

	private function _join_member(){
		$this->auth();
		
		$model  = M();
		$record = $model->table('card_member')->where(array('member_id'=>intval($_GET['member_id']),'store_id'=>intval($_GET['store_id'])))->find();
		
		if(!empty($record)){
			throw_exception();	
		}

		$member = $model->table('member')->where(array('member_id'=>intval($_GET['member_id'])))->find();
		$store	= $model->table('store')->where(array('store_id'=>intval($_GET['store_id'])))->find();
		
		

		$data	=	array(
			'member_id'		=>	$member['member_id'],
			'member_name'	=>	$member['member_name'],
			'store_id'		=>	$store['store_id'],
			'store_name'	=>	$store['store_name']
		);

		
		$result = $model->table('card_member')->insert($data);
		echo json_encode(array('code'=>self::SUCC,'datas'=>'1'));//3.申请成功,等待商家审核
		exit;
	}
	
	private function _login(){
		$username = trim($_POST['username']);
		$password =	md5(trim($_POST['password']));
		
		$model = M();
		$condition	=	array(
			'member_name'	=>	$username,
			'password'		=>	$password	
		); 
		$member = $model->fields('member_id,member_name,password')->table('member')->where($condition)->find();
		
		if(empty($member)){
			throw_exception();
		}
		
		$sign		= $member['member_name'].'-'.$member['password'].'-'.date("Ymd");
		$encrypt	= $this->encrypt($sign);
		
		$data = array(
			'code'		=>	self::SUCC,
			'datas'		=>	array('member_id'=>$member['member_id'],'sign'=>$encrypt)
		);
		
		echo json_encode($data);
		exit;
	}

	private function _memberinfo(){
		$this->auth();
		
		$member_id	= intval($_GET['member_id']);
		$model  = M();
		$member = $model->fields("member_name,nickname,comment_num,avatar,usercity,gender")->table('member')->where(array('member_id'=>$member_id))->find();
			
		if(!empty($member)){
			if(!empty($member['avatar'])){
				$member['avatar']	= SiteUrl.'/data/upload/shop/member/'.$member['avatar'];
			}else{
				$member['avatar']	= SiteUrl.'/data/upload/shop/member/member.png';
			}
			
			$city = $model->fields("area_name")->table("area")->where(array("area_id"=>$member['usercity']))->find();
			$member['cityname']		= $city['area_name'];
		}
		
		$data = array(
			'code'		=>	self::SUCC,
			'datas'		=>	$member
		);
		
		echo json_encode($data);
		exit;
	}	
	
	
	private function _editinfo(){
		$this->auth();
		
		$model = M();		
		$params	=	array(
			'member_id'	=> intval($_GET['member_id'])		
		);
		
		$condition	=	array();
		if(isset($_GET['city_id']) && !empty($_GET['city_id'])){
			$condition['usercity'] = intval($_GET['city_id']);
		}
		
		if(isset($_GET['nickname']) && !empty($_GET['nickname'])){
			$condition['nickname'] = $_GET['nickname'];
		}
		
		if(isset($_GET['gender']) && !empty($_GET['gender'])){
			$condition['gender']   = intval($_GET['gender']);	
		}
		
		$result = $model->table('member')->where($params)->update($condition);
		if($result){
			echo json_encode(array('code'=>self::SUCC,'datas'=>1));//1.编辑成功
			exit;
		}else{
			throw_exception();
		}
	}
	
	
	private function auth(){
		$data	=	($_SERVER['REQUEST_METHOD']=='POST')?$_POST:$_GET;
	
		$mobile_str = $this->decrypt($data['sign']);
		$mobile_arr = explode('-',$mobile_str);

		$model = M();
		$condition	=	array(
			'member_name'	=>	$mobile_arr[0],
			'password'		=>	$mobile_arr[1]	
		);
		
		$member = $model->fields('member_id')->table('member')->where($condition)->find();
		if(empty($member)){
			throw_exception();
		}
		
		if($member['member_id'] != intval($data['member_id'])){
			throw_exception();
		}
	}
	/*
	 *	搜索店铺
	 */
	private function _searchstore(){
		$keyword = trim($_GET['keyword']);
		
		$model = M();
		$store = $model->fields('store_id,store_name,person_consume,pic,address')->table('store')->where(array('like'=>array('store_name'=>"%{$keyword}%"),'is_audit'=>2,'city_id'=>intval($_GET['city_id'])))->select();//1.待审核 2.审核通过 3.审核未通过
		
		if(!empty($store)){
			foreach($store as $key=>$val){
				$store[$key]['pic'] = 	SiteUrl.'/data/upload/shop/store/'.$val['pic'];		
			}	
		}
		
		echo json_encode(array('code'=>self::SUCC,'datas'=>$store));
		exit;
	}



	/*
	 *	店铺详情
	 */
	private function _store(){
		$store_id = intval($_GET['store_id']);
		$model = M();
		$store = $model->table('store')->where(array('store_id'=>$store_id,'is_audit'=>2))->find();

		//商铺存在，审核通过 2.审核通过
		if(empty($store)){
			throw_exception();
		}

		$comment = $model->fields('comment_id,'.DBPRE.'comment.member_name,comment,photo,add_time,person_cost,avatar')->table('comment')->join("left join ".DBPRE."member on ".DBPRE."comment.member_id = ".DBPRE."member.member_id")->where(array('store_id'=>$store_id))->order('add_time desc')->limit("0,3")->select();

		if(!empty($comment)){
			//图片地址处理
			foreach($comment as $key=>$val){
				if(!empty($val['photo'])){
					$photo_str = '';
					$photo = explode(',',$val['photo']);
					foreach($photo as $v){
						$photo_str.= SiteUrl.'/data/upload/shop/comment/'.$v.',';
					}
					$comment[$key]['photo'] = trim($photo_str,',');
				}

				if(!empty($val['avatar'])){
					$comment[$key]['avatar'] = SiteUrl.'/data/upload/shop/member/'.$val['avatar'];	
				}else{
					$comment[$key]['avatar'] = SiteUrl.'/data/upload/shop/member/member.png';
				}
			}	
		}
		
		$data	=	array(
			'store_id'		=>	$store['store_id'],
			'store_name'	=>	$store['store_name'],
			'person_consume'=>	$store['person_consume'],
			'telephone'		=>	$store['telephone'],
			'address'		=>	$store['address'],
			'logo'			=>	SiteUrl.'/data/upload/shop/store/'.$store['logo'],
			'side'			=>	$store['side'],
			'business_hour'	=>	$store['business_hour'],
			'bus'			=>	$store['bus'],
			'subway'		=>	$store['subway'],
			'comment'		=>	$comment
		);
		
		echo json_encode(array('code'=>self::SUCC,'datas'=>$data));
		exit;
	}
	
	/**
	 * 帮助中心文章
	 * */
	private function _article(){
	    global $art_list;
	    $class_id = '2'; //设置要读取的文章所属分类顶级分类编号 ，多个分类用逗号分割
	    $model = M();
	    $class_all_id = $class_id;
	    
	    $type_id = $model->field('ac_id,ac_parent_id')->table('article_class')->where(array('in'=>array('ac_parent_id'=>$class_id)))->select();
	    if(!empty($type_id)){
	        $class_all_id = '';
	        foreach($type_id as $val){
	            $class_all_id .= $val['ac_id'].",";
	        }
	        $class_all_id = substr($class_all_id,0,-1);	        
	    }
	    
	    $where['in'] = array('ac_id'=>$class_all_id);
	    $where['article_show'] = 1;
	    
	    $article = $model->fields('article_id,ac_id,article_url,article_title,article_content')->table('article')->where($where)->order('article_sort')->select();
	    
	    $art_type = $model->fields('ac_id,ac_name')->table('article_class')->where(array('ac_parent_id'=>'0','in'=>array('ac_id'=>$class_id)))->select();
	    $art_list = array();
	    foreach((array)$art_type as $type){
	        $art_list[$type['ac_name']] = array();
	        $flag = 0;
	        if(!empty($type_id)){
    	        foreach($type_id as $tyid){
    	            print_r($tyid);
    	           foreach((array)$article as $art){
    	               if($art['ac_id'] == $tyid['ac_id'] && $tyid['ac_parent_id'] == $type['ac_id']){
    	                   $art_list[$type['ac_name']][$flag] = $art;
    	                   $flag++;
    	               }
    	           }
    	        }
	        }else{
	           foreach((array)$article as $art){
                  if($art['ac_id'] == $type['ac_id']){
                      $art_list[$type['ac_name']][$flag] = $art;
                      $flag++;
                   }
                }
	        }
	    }
	    $file = BasePath."/templates/article.php";
	    if(file_exists($file)){
	         require($file);
	    }else{
	        echo '数据错误';
	    }
	}


	private function _allcomment(){
		$offset = isset($_GET['pagenumber'])?intval($_GET['pagenumber']):self::PAGE_NUM;
		$offset = $offset - 1;
		$number = isset($_GET['pagesize'])?intval($_GET['pagesize']):self::PAGE_SIZE;
		$offset = $offset*$number;

		$store_id = intval($_GET['store_id']);
		$model = M();
		$store = $model->fields('store_id,store_name')->table('store')->where(array('store_id'=>$store_id,'is_audit'=>2))->find();//is_audit=2 为店铺审核通过
		
		if(empty($store)){
			throw_exception();
		}
		
		$comment = $model->fields('comment_id,'.DBPRE.'comment.member_name,comment,photo,add_time,person_cost,avatar')->table('comment')->join("left join ".DBPRE."member on ".DBPRE."comment.member_id = ".DBPRE."member.member_id")->where(array('store_id'=>$store_id))->order('add_time desc')->limit("{$offset},{$number}")->select();

		//查询评论总数
		$count = $model->table('comment')->where(array('store_id'=>$store_id))->count();
		$total = $count-$offset;
		if(!empty($comment)){
			//图片地址处理
			foreach($comment as $key=>$val){
				if(!empty($val['photo'])){
					$photo_str = '';
					$photo = explode(',',$val['photo']);
					foreach($photo as $v){
						$photo_str.= SiteUrl.'/data/upload/shop/comment/'.$v.',';
					}
					$comment[$key]['photo'] = trim($photo_str,',');
				}	
				
				if(!empty($val['avatar'])){
					$comment[$key]['avatar'] = SiteUrl.'/data/upload/shop/member/'.$val['avatar'];	
				}else{
					$comment[$key]['avatar'] = SiteUrl.'/data/upload/shop/member/member.png';
				}
			}	
		}
		
		
		$data	=	array(
			'code'		=>	self::SUCC,
			'datas'		=>	$comment,
			'count'		=>	$count,
			'haveMore'	=>	$total>=$number?'true':'false'
		);
		echo json_encode($data);
		exit;
	}

	private function _addcomment(){
		//身份验证
		$this->auth();
		
		$photo = '';
		if(!empty($_FILES['pic_1']['name'])){
			$pic_1_name = md5(uniqid(rand(),true)).'.jpg';//图片1
			if(move_uploaded_file($_FILES['pic_1']['tmp_name'],BASE_DATA_PATH.'/upload/shop/comment/'.$pic_1_name)){
				$photo.=$pic_1_name.',';
			}		
		}

		if(!empty($_FILES['pic_2']['name'])){
			$pic_2_name = md5(uniqid(rand(),true)).'.jpg';//图片2
			if(move_uploaded_file($_FILES['pic_2']['tmp_name'],BASE_DATA_PATH.'/upload/shop/comment/'.$pic_2_name)){
				$photo.=$pic_2_name.',';
			}
		}

		if(!empty($_FILES['pic_3']['name'])){
			$pic_3_name = md5(uniqid(rand(),true)).'.jpg';//图片3
			if(move_uploaded_file($_FILES['pic_3']['tmp_name'],BASE_DATA_PATH.'/upload/shop/comment/'.$pic_3_name)){
				$photo.=$pic_3_name.',';
			}
		}

		if(!empty($_FILES['pic_4']['name'])){
			$pic_4_name = md5(uniqid(rand(),true)).'.jpg';//图片4
			if(move_uploaded_file($_FILES['pic_4']['tmp_name'],BASE_DATA_PATH.'/upload/shop/comment/'.$pic_4_name)){
				$photo.=$pic_4_name.',';
			}
		}
		
		if(empty($_POST)){
			throw_exception();
		}
		
		$model  = M();
		$member = $model->table('member')->where(array('member_id'=>intval($_POST['member_id'])))->find();
		$store	= $model->table('store')->where(array('store_id'=>intval($_POST['store_id'])))->find();
		
		$data	=	array(
			'person_cost'	=>	intval($_POST['person_cost']),
			'photo'			=>	empty($photo)?'':trim($photo,','),
			'comment'		=>	$_POST['comment'],
			'store_id'		=>	$store['store_id'],
			'store_name'	=>	$store['store_name'],
			'member_id'		=>	$member['member_id'],
			'member_name'	=>	$member['member_name'],
			'add_time'		=>	time(),
			'city_id'		=>	$member['usercity']
		);	
		
		$result = $model->table('comment')->insert($data);
		if($result){
			echo json_encode(array('code'=>self::SUCC,'datas'=>'true'));
			exit;
		}else{
			echo json_encode(array('code'=>self::SUCC,'datas'=>'false'));
			exit;
		}
	}

	/**
	 *	预存款支付
	 */
	public function _predeposit(){
		//身份验证
		$this->auth();

		$model = M();
		$order = $model->fields("order_sn,item_name,price")->table("order")->where(array('order_sn'=>intval($_POST['order_sn'])))->find();
		
		$member = $model->fields("predeposit")->table("member")->where(array('member_id'=>intval($_POST['member_id'])))->find();

		$price = $member['predeposit'] - $order['price'];
		
		if($price < 0){
			throw_exception();
		}
		
		$result = $model->table("member")->where(array('member_id'=>intval($_POST['member_id'])))->update(array("predeposit"=>$price));
		if($result){
			$result1 = $model->table('order')->where(array('order_sn'=>intval($_POST['order_sn'])))->update(array("state"=>2));
			if($result1){
				echo json_encode(array('code'=>self::SUCC,'datas'=>'true'));
				exit;
			}else{
				throw_exception();
			}
		}else{
			throw_exception();
		}
	}

	public function _payment(){
		//身份验证
		$this->auth();
		
		$model = M();
		$order = $model->fields("order_sn,item_name,price")->table("order")->where(array('order_sn'=>intval($_GET['order_sn'])))->find();
		
		$member = $model->fields("predeposit")->table("member")->where(array('member_id'=>intval($_POST['member_id'])))->find();
		$price = $order['price'] - $member['predeposit'];
 		
		//订单信息
		$order_info		=	array(
			'order_sn'	=>	$order['order_sn'],
			'item_name'	=>	$order['item_name'],
			'price'		=>	$price
		);		
		
		require("alipay/alipay.php");
		$payment_api = new Alipay($order_info);
		$payment_api->submit();
		exit;
	}

	
	private function _repayment(){
		//身份验证
		$this->auth();

		$model = M();
		$order = $model->fields("order_sn,item_name,price,number")->table('order')->where(array('order_sn'=>$_GET['order_sn'],'state'=>1))->find();//状态 1.未支付 2.已支付 3.已消费
		
		if(empty($order)){
			throw_exception();
		}

		$member = $model->fields("predeposit")->table('member')->where(array('member_id'=>intval($_POST['member_id'])))->find();

		$data	=	array(
			'group_name'	=>	$order['item_name'],
			'number'		=>	$order['number'],
			'price'			=>	$order['price'],
			'order_sn'		=>	$order['order_sn'],
			'predeposit'	=>	$member['predeposit']
		);

		echo json_encode(array('code'=>self::SUCC,'datas'=>$data));
		exit;
	}

	
	private function encrypt($txt, $key = ''){
		if (empty($txt)) return $txt;
		if (empty($key)) $key = md5(MD5_KEY);
		$chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_.";
		$ikey ="-x6g6ZWm2G9g_vr0Bo.pOq3kRIxsZ6rm";
		$nh1 = rand(0,64);
		$nh2 = rand(0,64);
		$nh3 = rand(0,64);
		$ch1 = $chars{$nh1};
		$ch2 = $chars{$nh2};
		$ch3 = $chars{$nh3};
		$nhnum = $nh1 + $nh2 + $nh3;
		$knum = 0;$i = 0;
		while(isset($key{$i})) $knum +=ord($key{$i++});
		$mdKey = substr(md5(md5(md5($key.$ch1).$ch2.$ikey).$ch3),$nhnum%8,$knum%8 + 16);
		$txt = base64_encode(time().'_'.$txt);
		$txt = str_replace(array('+','/','='),array('-','_','.'),$txt);
		$tmp = '';
		$j=0;$k = 0;
		$tlen = strlen($txt);
		$klen = strlen($mdKey);
		for ($i=0; $i<$tlen; $i++) {
			$k = $k == $klen ? 0 : $k;
			$j = ($nhnum+strpos($chars,$txt{$i})+ord($mdKey{$k++}))%64;
			$tmp .= $chars{$j};
		}
		$tmplen = strlen($tmp);
		$tmp = substr_replace($tmp,$ch3,$nh2 % ++$tmplen,0);
		$tmp = substr_replace($tmp,$ch2,$nh1 % ++$tmplen,0);
		$tmp = substr_replace($tmp,$ch1,$knum % ++$tmplen,0);
		return $tmp;
	}


	private function decrypt($txt, $key = '', $ttl = 0){
		if (empty($txt)) return $txt;
		if (empty($key)) $key = md5(MD5_KEY);

		$chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_.";
		$ikey ="-x6g6ZWm2G9g_vr0Bo.pOq3kRIxsZ6rm";
		$knum = 0;$i = 0;
		$tlen = strlen($txt);
		while(isset($key{$i})) $knum +=ord($key{$i++});
		$ch1 = $txt{$knum % $tlen};
		$nh1 = strpos($chars,$ch1);
		$txt = substr_replace($txt,'',$knum % $tlen--,1);
		$ch2 = @$txt{$nh1 % $tlen};
		$nh2 = @strpos($chars,$ch2);
		$txt = @substr_replace($txt,'',$nh1 % $tlen--,1);
		$ch3 = $txt{$nh2 % $tlen};
		$nh3 = @strpos($chars,$ch3);
		$txt = substr_replace($txt,'',$nh2 % $tlen--,1);
		$nhnum = $nh1 + $nh2 + $nh3;
		$mdKey = substr(md5(md5(md5($key.$ch1).$ch2.$ikey).$ch3),$nhnum % 8,$knum % 8 + 16);
		$tmp = '';
		$j=0; $k = 0;
		$tlen = strlen($txt);
		$klen = strlen($mdKey);
		for ($i=0; $i<$tlen; $i++) {
			$k = $k == $klen ? 0 : $k;
			$j = strpos($chars,$txt{$i})-$nhnum - ord($mdKey{$k++});
			while ($j<0) $j+=64;
			$tmp .= $chars{$j};
		}
		$tmp = str_replace(array('-','_','.'),array('+','/','='),$tmp);
		$tmp = trim(base64_decode($tmp));
		
		if (preg_match("/\d{10}_/s",substr($tmp,0,11))){
			if ($ttl > 0 && (time() - substr($tmp,0,11) > $ttl)){
				$tmp = null;
			}else{
				$tmp = substr($tmp,11);
			}
		}
		return $tmp;
	}


	private function callback($data,$code=200){
			if (strtoupper(CHARSET) == 'GBK'){
				$data = charset($data,'GBK','UTF-8');
			}
			if ($_GET['debug'] == '1'){
				if ($code != 200){
					echo $code;exit;
				}else{
					echo '<pre>';
					print_R($data);
					echo '</pre>';
					exit();
				}
			}else{
				return json_encode(array('code'=>$code,'datas'=>$data));
			}
	}	
}

new run();

?>