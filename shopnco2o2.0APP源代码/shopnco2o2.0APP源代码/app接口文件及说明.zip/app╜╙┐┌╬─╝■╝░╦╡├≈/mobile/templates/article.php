<!DOCTYPE html>
<html><head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<title>帮助中心</title>
<link href="<?php echo SiteUrl;?>/mobile/templates/css/style.css" rel="stylesheet" type="text/css">
<script type="text/javascript">
	//图片延迟加载
	
	var temp = -1;//用来判断是否是向下滚动（向上滚动就不需要判断延迟加载图片了）
//	var count = 0;
	window.onscroll = function() { 
	var imgs = document.getElementsByTagName("img");
     //取元素的页面绝对 Y位置
    var getTop = function (El){
     var top = 0;
        do{
           top += El.offsetTop;
          }while((El = El.offsetParent).nodeName != 'BODY');
          return top;
     }
	
    //读取滚动条的位置和浏览器窗口的显示大小
		var top = scrollY,
            height = document.documentElement.clientHeight;
		
		if(temp < top){
			//对所有图片进行批量判断是否在浏览器显示区域内
         for(var i=0 ; i < imgs.length; i++){
         var _top = getTop(imgs[i]);
		//判断图片是否在显示区域内
         if( _top >= top &&_top <= top+height){
			var _src = imgs[i].getAttribute('lazy-src');
			//如果图片已经显示，则取消赋值
			if(imgs[i].src.indexOf(_src) < 0){
				imgs[i].src = _src;
		//		alert("count:" + count);
		//		count++;
			}
		 }
       }
	   temp = top;
	}
    
     };

</script>
</head>

<body>
<?php global $art_list;?>
<section>
  <?php if(!empty($art_list)){?>
  <?php foreach((array)$art_list as $type=>$art){ $a_flag = 0;?>
  <article class="help">
  	<div class="hd">
    	<h3><?php echo $type;?></h3>
    </div>
    <div class="con">
    	<ul>
        <?php foreach((array)$art as $val){ $a_flag++;?>
      	<li>
          <div class="tit">
          
           <h4><?php echo $a_flag.'.'.$val['article_title'];?></h4>
           <i class="icon-arr-up"></i>
          </div>
          <div class="txt">
        	<?php echo $val['article_content'];?>
          </div>
        </li>
        <?php }?>
      </ul>
    </div>
  </article>
  <?php }?>
  <?php }?>
</section>
<script type="text/javascript">
function addClass(obj, cls){
    var obj_class = obj.className,//获取 class 内容.
    blank = (obj_class != '') ? ' ' : '';//判断获取到的 class 是否为空, 如果不为空在前面加个'空格'.
    added = obj_class + blank + cls;//组合原来的 class 和需要添加的 class.
    obj.className = added;//替换原来的 class.
}
function removeClass(obj, cls){
    var obj_class = ' '+obj.className+' ';//获取 class 内容, 并在首尾各加一个空格. ex) 'abc        bcd' -> ' abc        bcd '
    obj_class = obj_class.replace(/(\s+)/gi, ' '),//将多余的空字符替换成一个空格. ex) ' abc        bcd ' -> ' abc bcd '
    removed = obj_class.replace(' '+cls+' ', ' ');//在原来的 class 替换掉首尾加了空格的 class. ex) ' abc bcd ' -> 'bcd '
    removed = removed.replace(/(^\s+)|(\s+$)/g, '');//去掉首尾空格. ex) 'bcd ' -> 'bcd'
    obj.className = removed;//替换原来的 class.
}
function hasClass(obj, cls){
    var obj_class = obj.className,//获取 class 内容.
    obj_class_lst = obj_class.split(/\s+/);//通过split空字符将cls转换成数组.
    x = 0;
    for(x in obj_class_lst) {
        if(obj_class_lst[x] == cls) {//循环数组, 判断是否包含cls
            return true;
        }
    }
    return false;
}
window.addEventListener('load', function () {

  var togglers = document.getElementsByClassName('tit');
  var len = togglers.length;
  for(var i = 0; i < len; i++) {
        (function (j) {
          togglers[j].addEventListener('click', function (e) {
              var nextEle = this.nextSibling.nextSibling;
              var iconEle = this.getElementsByTagName('i')[0];
              
              if(hasClass(nextEle, 'show-all')) {
                removeClass(nextEle, 'show-all');
                removeClass(iconEle, 'icon-arr-up');
                addClass(iconEle, 'icon-arr-d');
              } else {
                addClass(nextEle, 'show-all');
                addClass(iconEle, 'icon-arr-up');
                removeClass(iconEle, 'icon-arr-d');
              }
          }, false);
        })(i);
  }

},false);

</script>
</body></html>