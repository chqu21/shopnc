<?php
	class Model{
		private $query_type;
		private $link;
		private $options = array();


		public function __construct(){
			$this->_ini_db();
		}

		private function _ini_db(){
			$link = mysql_connect(DBHOST.':'.DBPORT,DBUSER,DBPWD) or throw_exception();
			mysql_select_db(DBNAME,$link) or throw_exception();

			$this->query_type	= 'mysql';
			$this->link = $link;

			if(strtoupper(CHARSET) == 'UTF-8'){
				$query_string = " SET CHARACTER_SET_CLIENT = utf8,
					 CHARACTER_SET_CONNECTION = utf8,
					 CHARACTER_SET_DATABASE = utf8,
					 CHARACTER_SET_RESULTS = utf8,
					 CHARACTER_SET_SERVER = utf8,
					 COLLATION_CONNECTION = utf8_general_ci,
					 COLLATION_DATABASE = utf8_general_ci,
					 COLLATION_SERVER = utf8_general_ci,
					 sql_mode=''";
			}else{
				$query_string = " SET CHARACTER_SET_CLIENT = gbk,
					 CHARACTER_SET_CONNECTION = gbk,
					 CHARACTER_SET_DATABASE = gbk,
					 CHARACTER_SET_RESULTS = gbk,
					 CHARACTER_SET_SERVER = gbk,
					 COLLATION_CONNECTION = gbk_chinese_ci,
					 COLLATION_DATABASE = gbk_chinese_ci,
					 COLLATION_SERVER = gbk_chinese_ci,
					 sql_mode=''";
			}
			mysql_query($query_string,$this->link);
		}

		public function __call($method,$args){
			if(in_array(strtolower($method),array('table','order','where','on','limit','having','group','fields','join'))){
				$this->options[strtolower($method)]	= $args[0];
			}elseif(in_array(strtolower($method),array('count','min','max','sum','avg'))){
				$field	= isset($args[0])?$args[0]:'*';
				return $this->get_field(strtoupper($method).'('.$field.') AS nc_'.$method, 'nc_'.$method);
			}
			return $this;
		}


		public function get_field($field,$op) {
			$options = $this->options;
			$where_str = ' where 1 and ';
			if(!empty($options['where'])){
				foreach($options['where'] as $k=>$v){
					if($k == 'like'){
						foreach($v as $key=>$val){
							$where_str.=" {$key} like '{$val}' and";
						}
					}elseif($k == 'gt'){
						foreach($v as $key=>$val){
							$where_str.=" {$key} > '{$val}' and";
						}
					}elseif($k == 'egt '){
						foreach($v as $key=>$val){
							$where_str.=" {$key} >= '{$val}' and";
						}
					}elseif($k == 'lt'){
						foreach($v as $key=>$val){
							$where_str.=" {$key} < '{$val}' and";
						}
					}elseif($k == 'elt'){
						foreach($v as $key=>$val){
							$where_str.=" {$key} <= '{$val}' and";
						}					
					}elseif($k == 'in'){
						foreach($v as $key=>$val){
							$where_str.=" {$key} in({$val}) and";
						}
					}else{
						$where_str.=" {$k}='{$v}' and";
					}
				}
			}
			
			$where_str = substr($where_str,0,-3);
			

			$sql	= "select ".$field." from ".DBPRE.$options['table'].$where_str;
			$result = mysql_query($sql,$this->link) or throw_exception(mysql_error());
			$array	= mysql_fetch_array($result,MYSQL_ASSOC);
			return $array[$op];
		}
		
		
		public function select(){
			$options = $this->options;

			if(empty($options['fields'])){
				$options['fields'] = '*';
			}
			
			if(empty($options['order'])){
				$options['order']	= '';
			}else{
				$options['order']	= 'order by '.$options['order'];
			}
			
			$where_str = ' where 1 and';
			if(!empty($options['where'])){	
				foreach($options['where'] as $k=>$v){
					if($k == 'like'){
						foreach($v as $key=>$val){
							$where_str.=" {$key} like '{$val}' and";
						}
					}elseif($k == 'gt'){
						foreach($v as $key=>$val){
							$where_str.=" {$key} > '{$val}' and";
						}
					}elseif($k == 'egt '){
						foreach($v as $key=>$val){
							$where_str.=" {$key} >= '{$val}' and";
						}
					}elseif($k == 'lt'){
						foreach($v as $key=>$val){
							$where_str.=" {$key} < '{$val}' and";
						}
					}elseif($k == 'elt'){
						foreach($v as $key=>$val){
							$where_str.=" {$key} <= '{$val}' and";
						}					
					}elseif($k == 'in'){
						foreach($v as $key=>$val){
							$where_str.=" {$key} in({$val}) and";
						}
					}else{
						$where_str.=" {$k}='{$v}' and";
					}		
				}
			}
			$where_str = substr($where_str,0,-3);
			$options['where'] = $where_str;
			
			//$tmp_table = explode(',',$options['table']);
			//if(count($tmp_table)>1){
			//	$options['table'] = $tmp_table[0];	
			//}

			if(empty($options['limit'])){
				$options['limit'] = ' limit 0,1000';	
			}else{
				$options['limit'] = ' limit '.$options['limit'];
			}
			
			$sql = "select ".$options['fields']." from ".DBPRE.$options['table'].' '.$options['join'].$where_str.$options['order'].$options['limit'];
			$result = mysql_query($sql,$this->link) or throw_exception(mysql_error());
			
			$array = array();
			while($tmp = mysql_fetch_array($result,MYSQL_ASSOC)){
				$array[] = $tmp;
			}
			$this->options = '';
			return $array;
		}
		
		public function insert($params){
		
			if(!is_array($params)) return false;
			$options = $this->options;
			$fields	=	array();
			$value	=	array();

			foreach($params as $key=>$val){
				$fields[] = self::parseKey($key);
				$value[]  = self::parseValue($val);
			}
			
			$sql = "INSERT INTO `".DBPRE.$options['table']."`(".implode(',',$fields).") VALUES(".implode(',',$value).")";
			mysql_query($sql,$this->link);
			$last_id = mysql_insert_id($this->link);
			return $last_id; 
		}
		
		
		/**
		 * 格式化字段
		 *
		 * @param string $key 字段名
		 * @return string
		 */
		public static function parseKey($key){
			$key   =  trim($key);
			if(!preg_match('/[,\'\"\*\(\)`.\s]/',$key)) {
			   $key = '`'.$key.'`';
			}
			return $key;
		}

	    /**
		 * 格式化值
		 *
		 * @param mixed $value
		 * @return mixed
		 */
		public static function parseValue($value){
			$value = addslashes(stripslashes($value));//重新加斜线，防止从数据库直接读取出错
			return "'".$value."'";
		}	

		public function update($params){
			if(empty($params)){
				return false;
			}
			
			$string_value = '';
			foreach($params as $k=>$v){
				$string_value.=" $k = '".$v."',";
			}

			$string_value = trim($string_value,',');
			$options = $this->options;
			$where_str = ' where 1 and';
			if(!empty($options['where'])){	
				foreach($options['where'] as $k=>$v){
					$where_str.=" {$k}='{$v}' and";
				}
			}
			$where_str = substr($where_str,0,-3);
			$options['where'] = $where_str;

			$sql = "update ".DBPRE.$options['table']." set ".$string_value.$where_str;
			$result = mysql_query($sql,$this->link);
			return $result;
		}
		

		public function find(){
			$array = $this->select();
			return $array[0];
		}
	}
	
	/**
	 *	实例化对象
	 */
	function M(){
		return new Model();
	}
	

	/**
	 *	异常处理
	 */
	function throw_exception(){
		echo json_encode(array('code'=>500,'datas'=>array()));
		exit;
	}

	/**
	 *	数据过滤
	 */
	function fliter(&$array){
		if (!empty($array)){
			while (list($k,$v) = each($array)) {
				if (is_string($v)) {
					$patterns = array("/<script.*>.*< {0,}\/script>/siU","/<iframe.*>.*< {0,}\/iframe>/siU","/<input(.*submit.*)(\>|\/\>)/siUe","/<form(.*action.*)>/siUe");
					$replacements = array('','','','');
					$v = preg_replace($patterns, $replacements, $v);					
					
					$v = preg_replace('/&amp;((#(\d{3,5}|x[a-fA-F0-9]{4})|[a-zA-Z][a-z0-9]{2,5});)/', '&\\1',
					str_replace(array('&', '"', '<', '>'), array('&amp;', '&quot;', '&lt;', '&gt;'), $v));

					if (!get_magic_quotes_gpc()){
						$array[$k] = addslashes(trim($v));
					}else {
						$array[$k] = trim($v);
					}
				}elseif (is_array($v))  {
					$array[$k] = fliter($v);
				}
			}
			return $array;
		}
	}
?>