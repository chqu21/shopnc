/** Automatically generated file. DO NOT MODIFY */
package com.shopnc_local_life.android;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}